package bg.tu_varna.sit.fragmentdemo.interfaces;

import bg.tu_varna.sit.fragmentdemo.models.Invitation;

public interface OnCreateInvitationListener {
    void onCreate(Invitation invitation);
}
